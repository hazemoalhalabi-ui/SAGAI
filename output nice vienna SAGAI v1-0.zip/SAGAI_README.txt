﻿
SAGAI – Streetscape Analysis with Generative AI
================================================

This archive contains output data and results generated from the SAGAI pipeline.
The folders are organized by module and include both intermediate and final results.

Included Folders:
-----------------
- Image_Analysis         → Raw outputs from Module 3 (image scoring)
- MAPS MODULE 1          → Maps and plots from OSM Point Generator
- MAPS MODULE 2          → Image availability and coverage maps
- MAPS MODULE 4          → Final thematic maps from scoring aggregation
- Spatial_Results        → Joined and processed GeoPackages
- StreetSamples          → OSM-based sampling layers (points and streets)
- Validation             → Patchwork visual comparisons for AI/Human validation

Note:
-----
Street View imagery itself is not included due to licensing restrictions.
All other outputs are provided for replication and inspection.

GitHub Repository:
------------------
https://github.com/perezjoan/SAGAI

For full documentation, scripts, and paper reference, please refer to the repository.

Author: Joan Perez
Version: SAGAI v1.0

